import io,pathlib,shutil,urllib.request,zipfile
url="https://downloads.godotengine.org/?version=4.7.2&flavor=stable&slug=export_templates.tpz&platform=templates"
head=urllib.request.Request(url,method="HEAD",headers={"User-Agent":"Mozilla/5.0"})
with urllib.request.urlopen(head,timeout=90) as r:size=int(r.headers["Content-Length"]);url=r.geturl()
class RR(io.RawIOBase):
 def __init__(self):self.pos=0;self.cs=-1;self.c=b""
 def readable(self):return True
 def seekable(self):return True
 def tell(self):return self.pos
 def seek(self,o,w=0):self.pos=o if w==0 else self.pos+o if w==1 else size+o if w==2 else self.pos;return self.pos
 def read(self,n=-1):
  if n is None or n<0:n=size-self.pos
  if not n or self.pos>=size:return b""
  end=min(size,self.pos+n);out=[];block=16*1024*1024
  while self.pos<end:
   if not(self.cs<=self.pos<self.cs+len(self.c)):
    s=(self.pos//block)*block;e=min(size,s+block)-1;q=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0","Range":f"bytes={s}-{e}"})
    with urllib.request.urlopen(q,timeout=120) as r:
     if r.status!=206:raise RuntimeError(f"Range HTTP {r.status}")
     self.c=r.read();self.cs=s
   o=self.pos-self.cs;t=min(end-self.pos,len(self.c)-o);out.append(self.c[o:o+t]);self.pos+=t
  return b"".join(out)
out=pathlib.Path.home()/".local/share/godot/export_templates/4.7.2.stable";out.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(RR()) as z:
 (out/"version.txt").write_bytes(z.read("templates/version.txt"))
 with z.open("templates/web_nothreads_release.zip") as a,(out/"web_nothreads_release.zip").open("wb") as b:shutil.copyfileobj(a,b,1024*1024)
