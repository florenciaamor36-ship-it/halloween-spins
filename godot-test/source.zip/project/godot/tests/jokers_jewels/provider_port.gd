extends Control

signal big_win_closed

# Isolated Godot test scene. Production Phaser files and the default project scene are untouched.
const FRAME_PATH := "res://assets/jokers-jewels/frame.webp"
# Original symbol cutouts decoded from the public demo atlases (S03-S09 plus S01 Bonus).
const SYMBOL_TEXTURE_PATHS := [
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/2cd840fac128dec4c9b2fe5eb5cac0a3/s_S03_000.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/09da5d1f6c772094082c117e203c368b/s_S04_000.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/dd71149d73f41c04c86a8db4e697af66/s_S05_000.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/011d743c8833aca4ca584beaccb9d5e0/s_S06_000.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/0e96b48a81d361f45a3af403c0f442a0/s_S07_000.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/bcafb640ce7e5444fbe485ffb5b0cd0e/s_S08_000.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/e5fd90bfc93f9384686ec6be14daefe7/s_S09_000.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/6c8e9a051697cd14d882d986564dc570/s_S01_000.webp"
]
const SYMBOL_HIGHLIGHT_PATHS := [
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/2cd840fac128dec4c9b2fe5eb5cac0a3/s_S03_HighlightOn.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/09da5d1f6c772094082c117e203c368b/s_S04_HighlightOn.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/dd71149d73f41c04c86a8db4e697af66/s_S05_HighlightOn.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/011d743c8833aca4ca584beaccb9d5e0/s_S06_HighlightOn.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/0e96b48a81d361f45a3af403c0f442a0/s_S07_HighlightOn.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/bcafb640ce7e5444fbe485ffb5b0cd0e/s_S08_HighlightOn.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/e5fd90bfc93f9384686ec6be14daefe7/s_S09_HighlightOn.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/6c8e9a051697cd14d882d986564dc570/s_S01_HighlightOn.webp"
]
const BIG_WIN_TITLE_PATHS := [
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/5182900dd28ca584d80e1395e03fee39/s_level_1.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/5182900dd28ca584d80e1395e03fee39/s_level_2.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/5182900dd28ca584d80e1395e03fee39/s_level_3.webp",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/5182900dd28ca584d80e1395e03fee39/s_level_4.webp"
]
const SYMBOL_KEYS := ["joker", "mandolina", "mazas", "botas", "gema-roja", "gema-celeste", "esfera-azul", "bonus"]
const SYMBOL_LABELS := ["Joker", "Mandolina", "Mazas", "Botas", "Gema roja", "Gema celeste", "Esfera azul", "BONUS"]
const SYMBOL_WEIGHTS := [139, 139, 139, 139, 139, 140, 140, 25]
const WEIGHT_TOTAL := 1000
const COLS := 5
const ROWS := 3
const SPIN_STRIP_SYMBOLS := 5
# loop0_common moves 4 source rows (4 × 178 units) in 0.1333 s.
const SOURCE_LOOP_DURATION := 0.1333333
const REEL_SCROLL_ROWS_PER_SECOND := 30.0
# Exact VS_LinesDefinitions paths from the static game package, converted to rows per reel.
const PAYLINES := [
	[1, 1, 1, 1, 1],
	[0, 0, 0, 0, 0],
	[2, 2, 2, 2, 2],
	[0, 1, 2, 1, 0],
	[2, 1, 0, 1, 2]
]
# The provider's five WinLineVisual components all use #2EF5FF at thickness 5.
const LINE_COLORS := [Color("#2EF5FF"), Color("#2EF5FF"), Color("#2EF5FF"), Color("#2EF5FF"), Color("#2EF5FF")]
# Same fictitious-credit table as the user's existing Joker's Jewels theme.
# BONUS is paid anywhere on the 15-cell board against the total bet; other symbols pay on fixed lines.
const PAYTABLE := {
	0: {3: 84.44, 4: 153.48, 5: 269.59},
	1: {3: 33.78, 4: 84.44, 5: 168.90},
	2: {3: 33.78, 4: 84.44, 5: 168.90},
	3: {3: 16.89, 4: 33.78, 5: 84.44},
	4: {3: 16.89, 4: 33.78, 5: 84.44},
	5: {3: 16.89, 4: 33.78, 5: 84.44},
	6: {2: 0.90, 3: 16.89, 4: 33.78, 5: 84.44},
	7: {3: 10.0, 4: 50.0, 5: 250.0}
}
# Local category used by this test build; this is not the provider's server tier table.
const LOCAL_BIG_WIN_MULTIPLIER := 10.0
const NORMAL_STOPS := [
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/game_2c5945eef37c8f843989fc1feaa5f774.ogg",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/game_8b11b54b721817d4ba95cfacd79af491.ogg",
	"",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/game_42e7dee34b4ce9442bbf2c7f71a5b613.ogg",
	"res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/game_41965fe4f5e42d44baf4babc1245047c.ogg"
]
const SOUND_PATHS := {
	"idle": "res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/game_03f479c4b31870b46a50406a8f4210aa.ogg",
	"spin": "res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/game_5a0f1cd858b757447bc8922c77638eda.ogg",
	"mandolin": "res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/game_449b467a62eb8f146958821523282d81.ogg",
	"bonus": "res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/game_8d33b7e80ab75454598a7d74ea9e7644.ogg",
	"small": "res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/game_15a5662eee5877144961aed23792af6f.ogg",
	"medium": "res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/GUI_e263a2caf6af0974fbf9a121ef142a97.ogg",
	"big_loop": "res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/GUI_d5dac4e3f146825419fd707cf3037780.ogg",
	"big_once": "res://godot/tests/jokers_jewels/provider-demo-assets/extracted/audio_ogg/game_8f89a6bf762dfd94ca4af48db13aaba6.ogg"
}

var rng := RandomNumberGenerator.new()
var balance := 10000.0
var bet := 50
var min_bet := 25
var max_bet := 500
var bet_step := 25
var grid: Array[int] = []
var symbols: Array[Sprite2D] = []
var highlight_sprites: Array[Sprite2D] = []
var symbol_textures: Array[Texture2D] = []
var symbol_highlight_textures: Array[Texture2D] = []
var line_layers: Array[Line2D] = []
var reel_views: Array[Control] = []
var spin_symbols: Array = []
var spin_base_scales: Array = []
var reel_spin_elapsed: Array[float] = []
var reel_is_moving: Array[bool] = []
var spin_result_grid: Array[int] = []
var spinning := false
var auto_active := false
var auto_remaining := 0
var turbo_active := false
var sound_enabled := true
var winning_lines: Array[int] = []
var winning_positions: Array[int] = []
var ui_labels: Dictionary = {}
var buttons: Dictionary = {}
var overlay: Control
var overlay_title: Label
var overlay_body: Label
var overlay_close: Button
var overlay_line_guide: TextureRect
var big_win_overlay: Control
var big_win_panel: Panel
var big_win_title: TextureRect
var big_win_title_textures: Array[Texture2D] = []
var big_win_amount: Label
var big_win_hint: Label
var big_win_title_tween: Tween
var music_players: Array[AudioStreamPlayer] = []
var music_index := 0
var sfx_player: AudioStreamPlayer
var award_player: AudioStreamPlayer
var bonus_player: AudioStreamPlayer
var big_loop_player: AudioStreamPlayer
var balance_value := 10000.0
var win_value := 0.0
var message_text := ""

func _ready() -> void:
	rng.randomize()
	_build_background()
	_build_reels()
	_build_audio()
	_build_hud()
	_build_overlay()
	_build_big_win_overlay()
	_layout()
	resized.connect(_layout)
	_randomize_initial_grid()
	_update_hud()
	_switch_music("idle")

func _process(delta: float) -> void:
	if not spinning:
		return
	for col in COLS:
		if not reel_is_moving[col]:
			continue
		var view := reel_views[col]
		var row_height := view.size.y / float(ROWS)
		var speed_multiplier := 1.6 if turbo_active else 1.0
		var scroll_distance := row_height * REEL_SCROLL_ROWS_PER_SECOND * speed_multiplier * delta
		reel_spin_elapsed[col] += delta
		var loop_phase := fposmod(reel_spin_elapsed[col], SOURCE_LOOP_DURATION) / SOURCE_LOOP_DURATION
		var loop_scale := 0.8 + 0.2 * sin(PI * loop_phase)
		for strip_index in SPIN_STRIP_SYMBOLS:
			var spin_sprite := spin_symbols[col][strip_index] as Sprite2D
			spin_sprite.position.y += scroll_distance
			while spin_sprite.position.y > view.size.y + row_height * 0.5:
				spin_sprite.position.y -= row_height * float(SPIN_STRIP_SYMBOLS)
				var next_symbol := _roll_symbol()
				spin_sprite.texture = symbol_textures[next_symbol]
				spin_base_scales[col][strip_index] = _fit_sprite_to_cell(spin_sprite, view.size.x, row_height)
			spin_sprite.scale = spin_base_scales[col][strip_index] * loop_scale

func _build_background() -> void:
	var background := TextureRect.new()
	background.name = "OriginalFrame"
	background.texture = _load_image_texture(FRAME_PATH)
	background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	background.stretch_mode = TextureRect.STRETCH_SCALE
	background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	background.z_index = -10
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)

func _load_image_texture(path: String) -> Texture2D:
	var image := Image.new()
	var error := image.load(ProjectSettings.globalize_path(path))
	if error != OK:
		push_error("Could not decode test asset: %s" % path)
		return null
	return ImageTexture.create_from_image(image)

func _build_reels() -> void:
	for path in SYMBOL_TEXTURE_PATHS:
		symbol_textures.append(_load_image_texture(path))
	for path in SYMBOL_HIGHLIGHT_PATHS:
		symbol_highlight_textures.append(_load_image_texture(path))
	grid.resize(COLS * ROWS)
	for col in COLS:
		var reel_view := Control.new()
		reel_view.name = "ReelClip_%d" % col
		reel_view.clip_contents = true
		reel_view.mouse_filter = Control.MOUSE_FILTER_IGNORE
		reel_view.z_index = 1
		add_child(reel_view)
		reel_views.append(reel_view)
		spin_symbols.append([])
		spin_base_scales.append([])
		reel_spin_elapsed.append(0.0)
		reel_is_moving.append(false)
	for cell in COLS * ROWS:
		var col := cell % COLS
		var sprite := Sprite2D.new()
		sprite.name = "Symbol_%02d" % cell
		sprite.texture = symbol_textures[0]
		sprite.centered = true
		sprite.z_index = 2
		reel_views[col].add_child(sprite)
		symbols.append(sprite)
		var highlight := Sprite2D.new()
		highlight.name = "SymbolHighlight_%02d" % cell
		highlight.texture = symbol_highlight_textures[0]
		highlight.centered = true
		highlight.z_index = 3
		highlight.modulate = Color(1, 1, 1, 0)
		highlight.visible = false
		reel_views[col].add_child(highlight)
		highlight_sprites.append(highlight)
	for col in COLS:
		for strip_index in SPIN_STRIP_SYMBOLS:
			var strip_symbol := Sprite2D.new()
			strip_symbol.name = "SpinSymbol_%d_%d" % [col, strip_index]
			strip_symbol.texture = symbol_textures[_roll_symbol()]
			strip_symbol.centered = true
			strip_symbol.z_index = 1
			strip_symbol.visible = false
			reel_views[col].add_child(strip_symbol)
			spin_symbols[col].append(strip_symbol)
			spin_base_scales[col].append(Vector2.ONE)
	for line_index in PAYLINES.size():
		var line := Line2D.new()
		line.name = "WinLine_%d" % line_index
		line.width = 5.0
		line.default_color = LINE_COLORS[line_index]
		line.antialiased = true
		line.z_index = 12
		line.visible = false
		add_child(line)
		line_layers.append(line)

func _build_audio() -> void:
	for index in 2:
		var player := AudioStreamPlayer.new()
		player.name = "Music_%d" % index
		player.volume_db = -80.0
		add_child(player)
		music_players.append(player)
	sfx_player = AudioStreamPlayer.new()
	sfx_player.name = "ReelSfx"
	add_child(sfx_player)
	award_player = AudioStreamPlayer.new()
	award_player.name = "AwardSfx"
	add_child(award_player)
	bonus_player = AudioStreamPlayer.new()
	bonus_player.name = "BonusSfx"
	add_child(bonus_player)
	big_loop_player = AudioStreamPlayer.new()
	big_loop_player.name = "BigWinLoop"
	add_child(big_loop_player)

func _build_hud() -> void:
	ui_labels["balance"] = _make_label("SALDO\n10.000", 9)
	ui_labels["bet"] = _make_label("APUESTA\n50", 9)
	ui_labels["lines"] = _make_label("LÍNEAS\n5", 9)
	ui_labels["win"] = _make_label("PREMIO\n0", 9)
	ui_labels["announcement"] = _make_label("", 16)
	ui_labels["announcement"].autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ui_labels["announcement"].z_index = 12
	ui_labels["announcement"].add_theme_color_override("font_color", Color("#fff0ad"))
	for key in ["balance", "bet", "lines", "win"]:
		ui_labels[key].add_theme_color_override("font_color", Color("#fff7d4"))

	_add_button("spin", "", _start_spin)
	_add_button("minus", "−", _decrease_bet)
	_add_button("plus", "+", _increase_bet)
	_add_button("auto", "", _toggle_auto)
	_add_button("info", "", _show_paytable)
	_add_button("turbo", "", _toggle_turbo)
	_add_button("bet_menu", "", _show_bet_menu)
	_add_button("menu", "", _show_menu)
	_add_button("settings", "", _toggle_sound)

func _make_label(text: String, font_size: int) -> Label:
	var label := Label.new()
	label.text = text
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", Color("#fff0ad"))
	label.add_theme_color_override("font_shadow_color", Color("#190927"))
	label.add_theme_constant_override("shadow_offset_x", 1)
	label.add_theme_constant_override("shadow_offset_y", 1)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.z_index = 10
	add_child(label)
	return label

func _add_button(key: String, label: String, callback: Callable) -> void:
	var button := Button.new()
	button.name = "Hit_%s" % key
	button.text = label
	button.flat = true
	button.focus_mode = Control.FOCUS_NONE
	button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	button.add_theme_font_size_override("font_size", 16)
	button.add_theme_color_override("font_color", Color(1, 1, 1, 0))
	button.add_theme_color_override("font_hover_color", Color(1, 1, 1, 0))
	button.add_theme_color_override("font_pressed_color", Color(1, 1, 1, 0))
	button.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0))
	button.add_theme_stylebox_override("normal", _transparent_style())
	button.add_theme_stylebox_override("hover", _transparent_style())
	button.add_theme_stylebox_override("pressed", _transparent_style())
	button.add_theme_stylebox_override("focus", _transparent_style())
	button.pressed.connect(callback)
	button.z_index = 20
	add_child(button)
	buttons[key] = button

func _transparent_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0, 0, 0, 0)
	style.border_color = Color(0, 0, 0, 0)
	style.set_border_width_all(0)
	style.set_corner_radius_all(0)
	return style

func _build_overlay() -> void:
	overlay = Control.new()
	overlay.name = "TestDialog"
	overlay.visible = false
	overlay.z_index = 40
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(overlay)
	var shade := ColorRect.new()
	shade.color = Color(0.04, 0.01, 0.08, 0.88)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay.add_child(shade)
	var panel := Panel.new()
	panel.name = "DialogPanel"
	panel.add_theme_stylebox_override("panel", _dialog_style())
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay.add_child(panel)
	var title_frame := TextureRect.new()
	title_frame.name = "OriginalPaytableHeader"
	title_frame.texture = _load_image_texture("res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/7da5eb61411288e448880a94799e926a/s_paytable_frame_landscape.webp")
	title_frame.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	title_frame.stretch_mode = TextureRect.STRETCH_SCALE
	title_frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(title_frame)
	overlay_line_guide = TextureRect.new()
	overlay_line_guide.name = "OriginalFiveLineGuide"
	overlay_line_guide.texture = _load_image_texture("res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/ebaa9af403729c54c9f581cb88b1e42a/s_5_lines.webp")
	overlay_line_guide.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	overlay_line_guide.stretch_mode = TextureRect.STRETCH_SCALE
	overlay_line_guide.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay_line_guide.visible = false
	panel.add_child(overlay_line_guide)
	overlay_title = Label.new()
	overlay_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay_title.add_theme_font_size_override("font_size", 28)
	overlay_title.add_theme_color_override("font_color", Color("#ffe88e"))
	panel.add_child(overlay_title)
	overlay_body = Label.new()
	overlay_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	overlay_body.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	overlay_body.add_theme_font_size_override("font_size", 17)
	overlay_body.add_theme_color_override("font_color", Color("#fff0d4"))
	panel.add_child(overlay_body)
	overlay_close = Button.new()
	overlay_close.text = "CERRAR"
	overlay_close.pressed.connect(_close_overlay)
	panel.add_child(overlay_close)

func _build_big_win_overlay() -> void:
	big_win_overlay = Control.new()
	big_win_overlay.name = "LocalBigWinOverlay"
	big_win_overlay.visible = false
	big_win_overlay.z_index = 60
	big_win_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	big_win_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	big_win_overlay.gui_input.connect(_on_big_win_overlay_input)
	add_child(big_win_overlay)
	var shade := ColorRect.new()
	shade.color = Color(0.035, 0.012, 0.075, 0.88)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	big_win_overlay.add_child(shade)
	big_win_panel = Panel.new()
	big_win_panel.name = "BigWinPanel"
	big_win_panel.add_theme_stylebox_override("panel", _dialog_style())
	big_win_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	big_win_overlay.add_child(big_win_panel)
	var header := TextureRect.new()
	header.name = "OriginalBigWinHeaderFrame"
	header.texture = _load_image_texture("res://godot/tests/jokers_jewels/provider-demo-assets/extracted/atlas_sprites/7da5eb61411288e448880a94799e926a/s_paytable_frame_landscape.webp")
	header.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	header.stretch_mode = TextureRect.STRETCH_SCALE
	header.mouse_filter = Control.MOUSE_FILTER_IGNORE
	big_win_panel.add_child(header)
	for title_path in BIG_WIN_TITLE_PATHS:
		big_win_title_textures.append(_load_image_texture(title_path))
	big_win_title = TextureRect.new()
	big_win_title.name = "OriginalBigWinTitle"
	big_win_title.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	big_win_title.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	big_win_title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	big_win_panel.add_child(big_win_title)
	big_win_amount = Label.new()
	big_win_amount.name = "BigWinAmount"
	big_win_amount.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big_win_amount.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	big_win_amount.add_theme_font_size_override("font_size", 32)
	big_win_amount.add_theme_color_override("font_color", Color("#fff0d4"))
	big_win_amount.mouse_filter = Control.MOUSE_FILTER_IGNORE
	big_win_panel.add_child(big_win_amount)
	big_win_hint = Label.new()
	big_win_hint.name = "BigWinTapHint"
	big_win_hint.text = "TOCÁ PARA VOLVER"
	big_win_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big_win_hint.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	big_win_hint.add_theme_font_size_override("font_size", 18)
	big_win_hint.add_theme_color_override("font_color", Color("#ffe88e"))
	big_win_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	big_win_panel.add_child(big_win_hint)

func _dialog_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color("#25103d")
	style.border_color = Color("#e4be64")
	style.set_border_width_all(3)
	style.set_corner_radius_all(18)
	style.content_margin_left = 24
	style.content_margin_right = 24
	style.content_margin_top = 24
	style.content_margin_bottom = 24
	return style

func _layout() -> void:
	if symbols.is_empty():
		return
	var view_size := size
	if view_size.x <= 0.0 or view_size.y <= 0.0:
		view_size = get_viewport_rect().size
	var cell_w := view_size.x / float(COLS)
	var reel_top := view_size.y * 0.3477
	var reel_height := view_size.y * 0.2285
	var cell_h := reel_height / float(ROWS)
	for col in COLS:
		reel_views[col].position = Vector2(col * cell_w, reel_top)
		reel_views[col].size = Vector2(cell_w, reel_height)
	for index in symbols.size():
		var col := index % COLS
		var row := int(index / COLS)
		var sprite := symbols[index]
		sprite.position = Vector2(cell_w * 0.5, (row + 0.5) * cell_h)
		_fit_sprite_to_cell(sprite, cell_w, cell_h)
		var highlight := highlight_sprites[index]
		highlight.position = sprite.position
		highlight.scale = sprite.scale
	for col in COLS:
		for strip_index in SPIN_STRIP_SYMBOLS:
			var strip_symbol := spin_symbols[col][strip_index] as Sprite2D
			strip_symbol.position = Vector2(cell_w * 0.5, (float(strip_index) - 0.5) * cell_h)
			spin_base_scales[col][strip_index] = _fit_sprite_to_cell(strip_symbol, cell_w, cell_h)
	_set_box(ui_labels["balance"], Vector2(0.0, 0.641), Vector2(0.25, 0.037), view_size)
	_set_box(ui_labels["bet"], Vector2(0.25, 0.641), Vector2(0.25, 0.037), view_size)
	_set_box(ui_labels["lines"], Vector2(0.50, 0.641), Vector2(0.25, 0.037), view_size)
	_set_box(ui_labels["win"], Vector2(0.75, 0.641), Vector2(0.25, 0.037), view_size)
	ui_labels["win"].pivot_offset = ui_labels["win"].size * 0.5
	_set_box(ui_labels["announcement"], Vector2(0.06, 0.578), Vector2(0.88, 0.052), view_size)
	_set_button_box("spin", Vector2(0.391, 0.678), Vector2(0.218, 0.093), view_size)
	_set_button_box("minus", Vector2(0.263, 0.703), Vector2(0.083, 0.052), view_size)
	_set_button_box("plus", Vector2(0.651, 0.703), Vector2(0.083, 0.052), view_size)
	_set_button_box("auto", Vector2(0.243, 0.845), Vector2(0.147, 0.055), view_size)
	_set_button_box("menu", Vector2(0.88, 0.845), Vector2(0.105, 0.055), view_size)
	_set_button_box("info", Vector2(0.0, 0.845), Vector2(0.105, 0.055), view_size)
	_set_button_box("turbo", Vector2(0.415, 0.845), Vector2(0.155, 0.055), view_size)
	_set_button_box("bet_menu", Vector2(0.595, 0.845), Vector2(0.155, 0.055), view_size)
	_set_button_box("settings", Vector2(0.88, 0.912), Vector2(0.105, 0.045), view_size)
	if is_instance_valid(overlay):
		var panel := overlay.get_node("DialogPanel") as Panel
		panel.position = Vector2(view_size.x * 0.08, view_size.y * 0.20)
		panel.size = Vector2(view_size.x * 0.84, view_size.y * 0.60)
		panel.pivot_offset = panel.size * 0.5
		var title_frame := panel.get_node("OriginalPaytableHeader") as TextureRect
		title_frame.position = Vector2(16, 8)
		title_frame.size = Vector2(panel.size.x - 32, 112)
		overlay_title.position = Vector2(22, 26)
		overlay_title.size = Vector2(panel.size.x - 44, 55)
		overlay_line_guide.position = Vector2(38, 122)
		overlay_line_guide.size = Vector2(panel.size.x - 76, 50)
		overlay_body.position = Vector2(30, 180)
		overlay_body.size = Vector2(panel.size.x - 60, panel.size.y - 285)
		overlay_close.position = Vector2(30, panel.size.y - 80)
		overlay_close.size = Vector2(panel.size.x - 60, 52)
	if is_instance_valid(big_win_panel):
		big_win_panel.position = Vector2(view_size.x * 0.08, view_size.y * 0.29)
		big_win_panel.size = Vector2(view_size.x * 0.84, view_size.y * 0.42)
		big_win_panel.pivot_offset = big_win_panel.size * 0.5
		var big_header := big_win_panel.get_node("OriginalBigWinHeaderFrame") as TextureRect
		big_header.position = Vector2(16, 18)
		big_header.size = Vector2(big_win_panel.size.x - 32, 112)
		big_win_title.position = Vector2(24, 24)
		big_win_title.size = Vector2(big_win_panel.size.x - 48, 96)
		big_win_title.pivot_offset = big_win_title.size * 0.5
		big_win_amount.position = Vector2(24, 175)
		big_win_amount.size = Vector2(big_win_panel.size.x - 48, 130)
		big_win_hint.position = Vector2(24, big_win_panel.size.y - 95)
		big_win_hint.size = Vector2(big_win_panel.size.x - 48, 55)
	_update_win_line_nodes()
	queue_redraw()

func _fit_sprite_to_cell(sprite: Sprite2D, cell_w: float, cell_h: float) -> Vector2:
	if sprite.texture == null:
		return Vector2.ONE
	var tex_size := sprite.texture.get_size()
	var desired := minf(cell_w * 0.78, cell_h * 0.92)
	var largest_side := maxf(float(tex_size.x), float(tex_size.y))
	var fitted_scale := Vector2.ONE * (desired / largest_side)
	sprite.scale = fitted_scale
	return fitted_scale

func _set_box(control: Control, origin: Vector2, dimensions: Vector2, view_size: Vector2) -> void:
	control.position = Vector2(origin.x * view_size.x, origin.y * view_size.y)
	control.size = Vector2(dimensions.x * view_size.x, dimensions.y * view_size.y)

func _set_button_box(key: String, origin: Vector2, dimensions: Vector2, view_size: Vector2) -> void:
	var button := buttons[key] as Button
	button.position = Vector2(origin.x * view_size.x, origin.y * view_size.y)
	button.size = Vector2(dimensions.x * view_size.x, dimensions.y * view_size.y)

func _randomize_initial_grid() -> void:
	for index in grid.size():
		grid[index] = _roll_symbol()
		_set_symbol(index, grid[index])

func _roll_symbol() -> int:
	var ticket := rng.randi_range(0, WEIGHT_TOTAL - 1)
	for index in SYMBOL_WEIGHTS.size():
		if ticket < SYMBOL_WEIGHTS[index]:
			return index
		ticket -= SYMBOL_WEIGHTS[index]
	return SYMBOL_WEIGHTS.size() - 1

func _set_symbol(cell: int, symbol_id: int) -> void:
	grid[cell] = symbol_id
	symbols[cell].texture = symbol_textures[symbol_id]
	symbols[cell].visible = true
	highlight_sprites[cell].texture = symbol_highlight_textures[symbol_id]
	highlight_sprites[cell].visible = false
	highlight_sprites[cell].modulate = Color(1, 1, 1, 0)

func _start_spin() -> void:
	if spinning or balance < float(bet):
		return
	spinning = true
	winning_lines.clear()
	winning_positions.clear()
	message_text = ""
	win_value = 0.0
	balance -= float(bet)
	spin_result_grid.clear()
	for cell in grid.size():
		spin_result_grid.append(_roll_symbol())
	for col in COLS:
		reel_is_moving[col] = true
		reel_spin_elapsed[col] = 0.0
		var view := reel_views[col]
		var row_height := view.size.y / float(ROWS)
		for row in ROWS:
			var cell := col + row * COLS
			symbols[cell].visible = false
			highlight_sprites[cell].visible = false
		for strip_index in SPIN_STRIP_SYMBOLS:
			var spin_sprite := spin_symbols[col][strip_index] as Sprite2D
			spin_sprite.position = Vector2(view.size.x * 0.5, (float(strip_index) - 0.5) * row_height)
			spin_sprite.texture = symbol_textures[_roll_symbol()]
			spin_base_scales[col][strip_index] = _fit_sprite_to_cell(spin_sprite, view.size.x, row_height)
			spin_sprite.visible = true
	_update_hud()
	big_loop_player.stop()
	_switch_music("spin")
	_run_spin()

func _run_spin() -> void:
	var first_stop := 1.15 if not turbo_active else 0.75
	var stop_interval := 0.28 if not turbo_active else 0.19
	var elapsed := 0.0
	for col in COLS:
		var stop_at := first_stop + float(col) * stop_interval
		await get_tree().create_timer(maxf(stop_at - elapsed, 0.0)).timeout
		elapsed = stop_at
		_stop_reel(col)
	await get_tree().create_timer(0.5).timeout
	await _finish_spin()

func _stop_reel(col: int) -> void:
	reel_is_moving[col] = false
	for spin_sprite in spin_symbols[col]:
		(spin_sprite as Sprite2D).visible = false
	var view := reel_views[col]
	var row_height := view.size.y / float(ROWS)
	for row in ROWS:
		var cell := col + row * COLS
		_set_symbol(cell, spin_result_grid[cell])
		var target := Vector2(view.size.x * 0.5, (row + 0.5) * row_height)
		var sprite := symbols[cell]
		sprite.position = target + Vector2(0, -row_height * 0.12)
		var tween := create_tween()
		tween.tween_property(sprite, "position", target, 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		# Source ReelsBump: 1.0 -> 1.1 at 0.083s -> 1.0 by 0.5s.
		var base_scale := sprite.scale
		var bump := create_tween()
		bump.tween_property(sprite, "scale", base_scale * 1.10, 0.0833).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		bump.tween_property(sprite, "scale", base_scale, 0.4167).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
	var mandolin_landed := false
	for row in ROWS:
		if grid[col + row * COLS] == 1:
			mandolin_landed = true
	if mandolin_landed:
		_play_sfx("mandolin")
	elif NORMAL_STOPS[col] != "":
		_play_path(NORMAL_STOPS[col])

func _finish_spin() -> void:
	var line_results := _evaluate_lines()
	var line_total := 0.0
	for result in line_results:
		line_total += result["amount"]
		winning_lines.append(result["line"])
		for cell in result["positions"]:
			if not winning_positions.has(cell):
				winning_positions.append(cell)
	var bonus_count := 0
	for symbol_id in grid:
		if symbol_id == 7:
			bonus_count += 1
	var bonus_total := 0.0
	if bonus_count >= 3:
		var bonus_table: Dictionary = PAYTABLE[7]
		var count_to_pay := mini(bonus_count, 5)
		bonus_total = float(bet) * float(bonus_table[count_to_pay])
		for cell in grid.size():
			if grid[cell] == 7 and not winning_positions.has(cell):
				winning_positions.append(cell)
	_update_win_line_nodes()
	win_value = line_total + bonus_total
	balance += win_value
	if bonus_count >= 3:
		message_text = "BONUS: %s fichas · %d símbolos" % [_format_credits(bonus_total), bonus_count]
	elif win_value > 0.0:
		message_text = "PREMIO: %s fichas" % _format_credits(win_value)
	else:
		message_text = ""
	_update_hud()
	if win_value > 0.0:
		_pulse_win_value()
	queue_redraw()
	if bonus_count >= 3:
		_play_sfx("bonus")
	if win_value > 0:
		_animate_winners()
		if win_value >= float(bet) * LOCAL_BIG_WIN_MULTIPLIER:
			_start_big_win_audio()
		elif win_value >= float(bet) * 3.0:
			_play_sfx("medium")
		else:
			_play_sfx("small")
	await get_tree().create_timer(2.0).timeout
	for cell in winning_positions:
		highlight_sprites[cell].visible = false
		highlight_sprites[cell].modulate = Color(1, 1, 1, 0)
	winning_lines.clear()
	winning_positions.clear()
	_update_win_line_nodes()
	queue_redraw()
	_switch_music("idle")
	spinning = false
	_update_hud()
	if auto_active:
		while big_win_overlay.visible:
			await big_win_closed
		auto_remaining -= 1
		if auto_remaining <= 0 or balance < float(bet):
			auto_active = false
		else:
			await get_tree().create_timer(0.7).timeout
			_start_spin()

func _evaluate_lines() -> Array[Dictionary]:
	var results: Array[Dictionary] = []
	for line_index in PAYLINES.size():
		var path: Array = PAYLINES[line_index]
		var symbol_id := int(grid[path[0]])
		if symbol_id == 7:
			continue
		var count := 0
		for col in COLS:
			if int(grid[col + int(path[col]) * COLS]) == symbol_id:
				count += 1
			else:
				break
		var table: Dictionary = PAYTABLE.get(symbol_id, {})
		if count >= 2 and table.has(count):
			var stake_per_line := float(bet) / 5.0
			var amount := stake_per_line * float(table[count])
			var paid_positions: Array[int] = []
			for col in count:
				paid_positions.append(col + int(path[col]) * COLS)
			results.append({"line": line_index, "symbol": symbol_id, "count": count, "amount": amount, "positions": paid_positions})
	return results

func _update_win_line_nodes() -> void:
	if line_layers.is_empty():
		return
	var reel_top := size.y * 0.3477
	var reel_height := size.y * 0.2285
	for line_index in line_layers.size():
		var line := line_layers[line_index]
		line.visible = winning_lines.has(line_index)
		if not line.visible:
			continue
		var path: Array = PAYLINES[line_index]
		var points := PackedVector2Array()
		for col in COLS:
			var row := int(path[col])
			points.append(Vector2((col + 0.5) * size.x / COLS, reel_top + (row + 0.5) * reel_height / ROWS))
		line.points = points

func _animate_winners() -> void:
	for cell in winning_positions:
		var sprite := symbols[cell]
		var base_scale := sprite.scale
		var scale_tween := create_tween()
		scale_tween.tween_property(sprite, "scale", base_scale * 1.10, 0.18).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		scale_tween.tween_property(sprite, "scale", base_scale, 0.18).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN)
		var highlight := highlight_sprites[cell]
		highlight.visible = true
		highlight.modulate = Color(1, 1, 1, 0)
		var flash_tween := create_tween().set_loops(4)
		flash_tween.tween_property(highlight, "modulate", Color(1, 1, 1, 0.85), 0.12)
		flash_tween.tween_property(highlight, "modulate", Color(1, 1, 1, 0.0), 0.12)

func _pulse_win_value() -> void:
	# Adapt GUI_PulseValue: scale 1.0 -> 1.32 at 0.033s -> 1.0 by 0.167s.
	var label := ui_labels["win"] as Label
	var pulse := create_tween()
	pulse.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	pulse.tween_property(label, "scale", Vector2.ONE * 1.32, 0.0333)
	pulse.tween_property(label, "scale", Vector2.ONE, 0.1334).set_ease(Tween.EASE_IN)

func _update_hud() -> void:
	ui_labels["balance"].text = "SALDO\n%s" % _format_credits(balance)
	ui_labels["bet"].text = "APUESTA\n%s" % _format_credits(bet)
	ui_labels["lines"].text = "LÍNEAS\n5"
	ui_labels["win"].text = "PREMIO\n%s" % _format_credits(win_value)
	ui_labels["announcement"].text = message_text
	buttons["spin"].disabled = spinning or balance < float(bet)
	buttons["minus"].disabled = spinning or bet <= min_bet
	buttons["plus"].disabled = spinning or bet >= max_bet
	buttons["auto"].tooltip_text = "PARAR AUTO" if auto_active else "AUTO · 10 tiradas"
	buttons["turbo"].tooltip_text = "Turbo activado" if turbo_active else "Turbo"
	buttons["settings"].tooltip_text = "Sonido activado" if sound_enabled else "Sonido desactivado"

func _format_credits(value: float) -> String:
	return "%.0f" % round(value)

func _increase_bet() -> void:
	if spinning:
		return
	bet = mini(bet + bet_step, max_bet)
	_update_hud()

func _decrease_bet() -> void:
	if spinning:
		return
	bet = maxi(bet - bet_step, min_bet)
	_update_hud()

func _toggle_auto() -> void:
	if spinning:
		auto_active = false
		return
	auto_active = not auto_active
	auto_remaining = 10 if auto_active else 0
	if auto_active:
		_start_spin()

func _toggle_turbo() -> void:
	turbo_active = not turbo_active
	message_text = "TURBO ACTIVADO" if turbo_active else "TURBO DESACTIVADO"
	_update_hud()

func _toggle_sound() -> void:
	sound_enabled = not sound_enabled
	if not sound_enabled:
		for player in music_players:
			player.stop()
		sfx_player.stop()
		award_player.stop()
		bonus_player.stop()
		big_loop_player.stop()
	else:
		_switch_music("idle")
	message_text = "SONIDO ACTIVADO" if sound_enabled else "SONIDO DESACTIVADO"
	_update_hud()

func _load_ogg(path: String) -> AudioStreamOggVorbis:
	var bytes := FileAccess.get_file_as_bytes(path)
	if bytes.is_empty():
		push_error("Could not read test audio: %s" % path)
		return null
	return AudioStreamOggVorbis.load_from_buffer(bytes)

func _switch_music(kind: String) -> void:
	if not sound_enabled:
		return
	var path: String = SOUND_PATHS[kind]
	var next_index := 1 - music_index
	var next_player := music_players[next_index]
	var stream := _load_ogg(path)
	if stream == null:
		return
	stream.loop = true
	var old_player := music_players[music_index]
	next_player.stop()
	next_player.stream = stream
	next_player.volume_db = -60.0
	next_player.play()
	var fade := create_tween()
	fade.tween_property(next_player, "volume_db", -9.0, 0.25)
	if old_player.playing:
		fade.parallel().tween_property(old_player, "volume_db", -60.0, 0.25)
		fade.tween_callback(old_player.stop)
	music_index = next_index

func _play_path(path: String, player: AudioStreamPlayer = null) -> void:
	if not sound_enabled or path.is_empty():
		return
	var stream := _load_ogg(path)
	if stream == null:
		return
	var target := sfx_player if player == null else player
	target.stream = stream
	target.play()

func _play_sfx(key: String) -> void:
	if not SOUND_PATHS.has(key):
		return
	var target := sfx_player
	if key == "bonus":
		target = bonus_player
	elif key in ["small", "medium", "big_once"]:
		target = award_player
	_play_path(SOUND_PATHS[key], target)

func _start_big_win_audio() -> void:
	if not sound_enabled:
		return
	var loop_stream := _load_ogg(SOUND_PATHS["big_loop"])
	if loop_stream != null:
		loop_stream.loop = true
	big_loop_player.stream = loop_stream
	big_loop_player.volume_db = -10.0
	big_loop_player.play()
	_play_sfx("big_once")

func _show_paytable() -> void:
	if spinning:
		return
	_close_overlay()
	overlay_line_guide.visible = true
	overlay_title.text = "JOKER’S JEWELS · PREMIOS"
	overlay_body.text = "Premios en fichas · 5 líneas fijas\n" + \
		"Los símbolos comunes pagan de izquierda a derecha; BONUS paga en cualquier posición.\n" + \
		"La esfera azul paga desde 2 símbolos. No hay WILD ni giros gratis.\n\n" + \
		"SÍMBOLO                 2      3       4       5\n" + \
		"Joker                         —     84,44  153,48  269,59\n" + \
		"Mandolina / Mazas             —     33,78   84,44  168,90\n" + \
		"Botas / Gemas                 —     16,89   33,78   84,44\n" + \
		"Esfera azul                 0,90    16,89   33,78   84,44\n" + \
		"BONUS (apuesta total)          —     10×     50×    250×\n\n" + \
		"Las cifras impresas en ARS en la máscara son decorativas. Las apuestas y premios usan fichas ficticias."
	_open_overlay()

func _show_menu() -> void:
	if spinning:
		return
	overlay_line_guide.visible = false
	overlay_title.text = "MENÚ"
	overlay_body.text = "PREMIOS: tocá el icono de información.\n" + \
		"APUESTA: usá el botón de monedas y los controles −/+.\n" + \
		"AUTO: inicia hasta 10 tiradas; podés detenerlo desde el mismo botón.\n" + \
		"TURBO: acelera el giro. SONIDO: se activa o silencia con el engranaje.\n\n" + \
		"Esta escena de prueba usa fichas ficticias y resultados locales."
	_open_overlay()

func _show_bet_menu() -> void:
	if spinning:
		return
	overlay_line_guide.visible = false
	overlay_title.text = "CONFIGURAR APUESTA"
	overlay_body.text = "Las 5 líneas son fijas.\n\nMonedas por línea: %s\nValor de ficha: 1\nApuesta total: %s\n\nUsá − y + en la pantalla para cambiar la apuesta." % [_format_credits(float(bet) / 5.0), _format_credits(bet)]
	_open_overlay()

func _open_overlay() -> void:
	overlay.visible = true
	_layout()
	var panel := overlay.get_node("DialogPanel") as Panel
	panel.pivot_offset = panel.size * 0.5
	panel.scale = Vector2.ONE * 1.2
	panel.modulate = Color(1, 1, 1, 0)
	var intro := create_tween()
	intro.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	intro.tween_property(panel, "scale", Vector2.ONE, 0.25)
	intro.parallel().tween_property(panel, "modulate", Color.WHITE, 0.25)

func _close_overlay() -> void:
	if is_instance_valid(overlay):
		overlay.visible = false
	if is_instance_valid(overlay_line_guide):
		overlay_line_guide.visible = false

# Explicit 1-based title level; payout logic intentionally does not select a title tier.
func _show_big_win_overlay(title_level: int, amount: float) -> bool:
	if title_level < 1 or title_level > big_win_title_textures.size() or amount < 0.0:
		return false
	big_win_title.texture = big_win_title_textures[title_level - 1]
	big_win_amount.text = "%s FICHAS" % _format_credits(amount)
	big_win_hint.text = "TOCÁ PARA VOLVER"
	big_win_overlay.visible = true
	_layout()
	big_win_title.scale = Vector2.ONE * 1.05
	if big_win_title_tween != null:
		big_win_title_tween.kill()
	big_win_title_tween = create_tween()
	big_win_title_tween.set_loops()
	big_win_title_tween.tween_property(big_win_title, "scale", Vector2.ONE * 0.95, 0.45).set_trans(Tween.TRANS_SINE)
	big_win_title_tween.tween_property(big_win_title, "scale", Vector2.ONE * 1.05, 0.4667).set_trans(Tween.TRANS_SINE)
	return true

func _close_big_win_overlay() -> void:
	if not is_instance_valid(big_win_overlay) or not big_win_overlay.visible:
		return
	big_win_overlay.visible = false
	if big_win_title_tween != null:
		big_win_title_tween.kill()
		big_win_title_tween = null
	big_win_title.scale = Vector2.ONE
	big_win_closed.emit()
	_update_hud()

func _on_big_win_overlay_input(event: InputEvent) -> void:
	var dismiss := false
	if event is InputEventScreenTouch and event.pressed:
		dismiss = true
	elif event is InputEventMouseButton and event.pressed:
		dismiss = true
	if dismiss:
		_close_big_win_overlay()
		get_viewport().set_input_as_handled()

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if big_win_overlay.visible:
			if event.keycode == KEY_SPACE or event.keycode == KEY_ENTER:
				_close_big_win_overlay()
			get_viewport().set_input_as_handled()
			return
		if event.keycode == KEY_SPACE or event.keycode == KEY_ENTER:
			if overlay.visible:
				_close_overlay()
			else:
				_start_spin()
			get_viewport().set_input_as_handled()
		elif event.keycode == KEY_M:
			_toggle_sound()
			get_viewport().set_input_as_handled()
