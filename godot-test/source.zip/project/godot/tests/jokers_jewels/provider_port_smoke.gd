extends SceneTree

func _initialize() -> void:
	call_deferred("_run_smoke")

func _run_smoke() -> void:
	var packed := load("res://godot/tests/jokers_jewels/provider_port.tscn") as PackedScene
	if packed == null:
		push_error("Provider port scene did not load")
		quit(1)
		return
	var game = packed.instantiate()
	root.add_child(game)
	await process_frame
	if not game.has_method("_start_spin"):
		push_error("Provider port script did not attach")
		quit(1)
		return
	if game.symbol_textures.size() != 8 or game.symbol_highlight_textures.size() != 8:
		push_error("Provider symbol assets were not loaded")
		quit(1)
		return
	for texture in game.symbol_textures:
		if texture == null:
			push_error("A provider symbol texture is missing")
			quit(1)
			return
	for texture in game.symbol_highlight_textures:
		if texture == null:
			push_error("A provider highlight texture is missing")
			quit(1)
			return
	game._start_spin()
	await create_timer(10.0).timeout
	if game.spinning:
		push_error("Test spin did not finish")
		quit(1)
		return
	for col in game.reel_views.size():
		if not game.reel_views[col].clip_contents or game.reel_is_moving[col]:
			push_error("A reel failed to clip or stop")
			quit(1)
			return
		for spin_sprite in game.spin_symbols[col]:
			if (spin_sprite as Sprite2D).visible:
				push_error("A scrolling symbol remained visible after stop")
				quit(1)
				return
	for cell in game.grid.size():
		game._set_symbol(cell, 1)
	game._set_symbol(5, 0)
	game._set_symbol(6, 0)
	game._set_symbol(7, 0)
	game.spinning = true
	await game._finish_spin()
	if game.win_value <= 0.0:
		push_error("Deterministic local winning result did not pay")
		quit(1)
		return
	if game.big_loop_player.stream == null or game.award_player.stream == null:
		push_error("Original big-win audio clips did not load")
		quit(1)
		return
	if game.big_win_overlay.visible:
		push_error("A local payout guessed a Big Win title tier")
		quit(1)
		return
	if game.big_win_title_textures.size() != 4:
		push_error("Original Big Win title sprites did not load")
		quit(1)
		return
	for title_texture in game.big_win_title_textures:
		if title_texture == null:
			push_error("An original Big Win title texture is missing")
			quit(1)
			return
	if game._show_big_win_overlay(0, game.win_value):
		push_error("Invalid Big Win title level was accepted")
		quit(1)
		return
	if not game._show_big_win_overlay(3, game.win_value):
		push_error("Explicit Big Win title selection failed")
		quit(1)
		return
	if not game.big_win_overlay.visible or game.big_win_title.texture != game.big_win_title_textures[2]:
		push_error("Explicit Big Win title was not shown")
		quit(1)
		return
	var touch_event := InputEventScreenTouch.new()
	touch_event.pressed = true
	game._on_big_win_overlay_input(touch_event)
	if game.big_win_overlay.visible:
		push_error("Touch did not dismiss the Big Win overlay")
		quit(1)
		return
	game._show_big_win_overlay(3, game.win_value)
	var escape_event := InputEventKey.new()
	escape_event.pressed = true
	escape_event.keycode = KEY_ESCAPE
	game._input(escape_event)
	if not game.big_win_overlay.visible:
		push_error("Escape incorrectly dismissed the Big Win overlay")
		quit(1)
		return
	var enter_event := InputEventKey.new()
	enter_event.pressed = true
	enter_event.keycode = KEY_ENTER
	game._input(enter_event)
	if game.big_win_overlay.visible:
		push_error("Enter did not dismiss the Big Win overlay")
		quit(1)
		return
	game._show_paytable()
	if not game.overlay.visible or not game.overlay_line_guide.visible:
		push_error("Original five-line paytable assets did not open")
		quit(1)
		return
	game._close_overlay()
	game._show_menu()
	if not game.overlay.visible or game.overlay_line_guide.visible:
		push_error("Menu overlay did not open cleanly")
		quit(1)
		return
	game._close_overlay()
	await create_timer(0.35).timeout
	for player in game.music_players:
		player.stop()
	game.sfx_player.stop()
	game.award_player.stop()
	game.bonus_player.stop()
	game.big_loop_player.stop()
	print("Provider assets/UI loaded; clipped reels, local Big Win overlay, paytable, and menu verified.")
	game.queue_free()
	await process_frame
	await process_frame
	quit(0)
